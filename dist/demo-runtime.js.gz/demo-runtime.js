/*! Liquid Glass Cards 3.5.0 | MIT; Vacuum Dock/HA animation Apache-2.0; Lit BSD-3-Clause | See licenses/ and THIRD-PARTY-LICENSES.md */
import{a,b,c,d}from"./chunks/chunk-BDBFODAO.js";export{c as createDemoRuntime,b as inlineDemoTemplates,d as loadDemoRuntime,a as ownDemoId};
